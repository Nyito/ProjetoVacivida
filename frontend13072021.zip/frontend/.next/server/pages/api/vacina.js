(function() {
var exports = {};
exports.id = "pages/api/vacina";
exports.ids = ["pages/api/vacina"];
exports.modules = {

/***/ "./pages/api/vacina.js":
/*!*****************************!*\
  !*** ./pages/api/vacina.js ***!
  \*****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

/* JWT secret key */

const KEY = process.env.JWT_KEY;
const urlApi = process.env.URL_API_BACKEND;

const register = async (req, res) => {
  const {
    method
  } = req;

  switch (method) {
    case 'POST':
      const {
        cpf,
        nome,
        dataNascimento
      } = req.body;
      /* Caso o usuário ou senha ou email estiverem em branco... */

      if (!cpf || !nome || !dataNascimento) {
        return res.status(400).json({
          success: false,
          message: 'trolou'
        });
      }

      try {
        const resposta = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${urlApi}/register`, {
          cpf: cpf,
          nome: nome,
          dataNascimento: dataNascimento,
          telefone: " ",
          endereco: " ",
          nomeMae: " ",
          nomeAplicador: " ",
          fabricante: " ",
          dose: " "
        });
        return res.status(201).json({
          success: true,
          message: resposta.data.message
        });
      } catch (e) {
        if (e.code == 'ECONNREFUSED') {
          return res.status(500).json({
            success: false,
            message: 'ECONNREFUSED: Não é possível se conectar à API no backend!'
          });
        }

        if (e.response.status == 400) {
          return res.status(400).json({
            success: false,
            message: e.response.data.message
          });
        }
      }

  }
};

/* harmony default export */ __webpack_exports__["default"] = (register);

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ (function(module) {

"use strict";
module.exports = require("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./pages/api/vacina.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sZWFybi1zdGFydGVyLy4vcGFnZXMvYXBpL3ZhY2luYS5qcyIsIndlYnBhY2s6Ly9sZWFybi1zdGFydGVyL2V4dGVybmFsIFwiYXhpb3NcIiJdLCJuYW1lcyI6WyJLRVkiLCJwcm9jZXNzIiwiZW52IiwiSldUX0tFWSIsInVybEFwaSIsIlVSTF9BUElfQkFDS0VORCIsInJlZ2lzdGVyIiwicmVxIiwicmVzIiwibWV0aG9kIiwiY3BmIiwibm9tZSIsImRhdGFOYXNjaW1lbnRvIiwiYm9keSIsInN0YXR1cyIsImpzb24iLCJzdWNjZXNzIiwibWVzc2FnZSIsInJlc3Bvc3RhIiwiYXhpb3MiLCJ0ZWxlZm9uZSIsImVuZGVyZWNvIiwibm9tZU1hZSIsIm5vbWVBcGxpY2Fkb3IiLCJmYWJyaWNhbnRlIiwiZG9zZSIsImRhdGEiLCJlIiwiY29kZSIsInJlc3BvbnNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTs7QUFDQSxNQUFNQSxHQUFHLEdBQUdDLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyxPQUF4QjtBQUVBLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDQyxHQUFSLENBQVlHLGVBQTNCOztBQUVBLE1BQU1DLFFBQVEsR0FBRyxPQUFPQyxHQUFQLEVBQVlDLEdBQVosS0FBb0I7QUFDbkMsUUFBTTtBQUFFQztBQUFGLE1BQWFGLEdBQW5COztBQUVBLFVBQVFFLE1BQVI7QUFDRSxTQUFLLE1BQUw7QUFDRSxZQUFNO0FBQUVDLFdBQUY7QUFBT0MsWUFBUDtBQUFhQztBQUFiLFVBQWdDTCxHQUFHLENBQUNNLElBQTFDO0FBQ0E7O0FBQ0EsVUFBSSxDQUFDSCxHQUFELElBQVEsQ0FBQ0MsSUFBVCxJQUFpQixDQUFDQyxjQUF0QixFQUFzQztBQUNwQyxlQUFPSixHQUFHLENBQUNNLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUMxQkMsaUJBQU8sRUFBRSxLQURpQjtBQUUxQkMsaUJBQU8sRUFBRTtBQUZpQixTQUFyQixDQUFQO0FBSUQ7O0FBQ0QsVUFBSTtBQUNGLGNBQU1DLFFBQVEsR0FBRyxNQUFNQyxpREFBQSxDQUFZLEdBQUVmLE1BQU8sV0FBckIsRUFBaUM7QUFDdERNLGFBQUcsRUFBRUEsR0FEaUQ7QUFFdERDLGNBQUksRUFBRUEsSUFGZ0Q7QUFHdERDLHdCQUFjLEVBQUVBLGNBSHNDO0FBSXREUSxrQkFBUSxFQUFFLEdBSjRDO0FBS3REQyxrQkFBUSxFQUFFLEdBTDRDO0FBTXREQyxpQkFBTyxFQUFFLEdBTjZDO0FBT3REQyx1QkFBYSxFQUFFLEdBUHVDO0FBUXREQyxvQkFBVSxFQUFFLEdBUjBDO0FBU3REQyxjQUFJLEVBQUU7QUFUZ0QsU0FBakMsQ0FBdkI7QUFZQSxlQUFPakIsR0FBRyxDQUFDTSxNQUFKLENBQVcsR0FBWCxFQUFnQkMsSUFBaEIsQ0FBcUI7QUFDMUJDLGlCQUFPLEVBQUUsSUFEaUI7QUFFMUJDLGlCQUFPLEVBQUVDLFFBQVEsQ0FBQ1EsSUFBVCxDQUFjVDtBQUZHLFNBQXJCLENBQVA7QUFJRCxPQWpCRCxDQWlCRSxPQUFPVSxDQUFQLEVBQVU7QUFDVixZQUFJQSxDQUFDLENBQUNDLElBQUYsSUFBVSxjQUFkLEVBQThCO0FBQzVCLGlCQUFPcEIsR0FBRyxDQUFDTSxNQUFKLENBQVcsR0FBWCxFQUFnQkMsSUFBaEIsQ0FBcUI7QUFDMUJDLG1CQUFPLEVBQUUsS0FEaUI7QUFFMUJDLG1CQUFPLEVBQ0w7QUFId0IsV0FBckIsQ0FBUDtBQUtEOztBQUNELFlBQUlVLENBQUMsQ0FBQ0UsUUFBRixDQUFXZixNQUFYLElBQXFCLEdBQXpCLEVBQThCO0FBQzVCLGlCQUFPTixHQUFHLENBQUNNLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUMxQkMsbUJBQU8sRUFBRSxLQURpQjtBQUUxQkMsbUJBQU8sRUFBRVUsQ0FBQyxDQUFDRSxRQUFGLENBQVdILElBQVgsQ0FBZ0JUO0FBRkMsV0FBckIsQ0FBUDtBQUlEO0FBQ0Y7O0FBekNMO0FBMkNELENBOUNEOztBQStDQSwrREFBZVgsUUFBZixFOzs7Ozs7Ozs7OztBQ3JEQSxtQyIsImZpbGUiOiJwYWdlcy9hcGkvdmFjaW5hLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gJ2F4aW9zJ1xyXG4vKiBKV1Qgc2VjcmV0IGtleSAqL1xyXG5jb25zdCBLRVkgPSBwcm9jZXNzLmVudi5KV1RfS0VZXHJcblxyXG5jb25zdCB1cmxBcGkgPSBwcm9jZXNzLmVudi5VUkxfQVBJX0JBQ0tFTkRcclxuXHJcbmNvbnN0IHJlZ2lzdGVyID0gYXN5bmMgKHJlcSwgcmVzKSA9PiB7XHJcbiAgY29uc3QgeyBtZXRob2QgfSA9IHJlcVxyXG5cclxuICBzd2l0Y2ggKG1ldGhvZCkge1xyXG4gICAgY2FzZSAnUE9TVCc6XHJcbiAgICAgIGNvbnN0IHsgY3BmLCBub21lLCBkYXRhTmFzY2ltZW50byB9ID0gcmVxLmJvZHlcclxuICAgICAgLyogQ2FzbyBvIHVzdcOhcmlvIG91IHNlbmhhIG91IGVtYWlsIGVzdGl2ZXJlbSBlbSBicmFuY28uLi4gKi9cclxuICAgICAgaWYgKCFjcGYgfHwgIW5vbWUgfHwgIWRhdGFOYXNjaW1lbnRvKSB7XHJcbiAgICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoNDAwKS5qc29uKHtcclxuICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICAgICAgbWVzc2FnZTogJ3Ryb2xvdScsXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3Bvc3RhID0gYXdhaXQgYXhpb3MucG9zdChgJHt1cmxBcGl9L3JlZ2lzdGVyYCwge1xyXG4gICAgICAgICAgY3BmOiBjcGYsXHJcbiAgICAgICAgICBub21lOiBub21lLFxyXG4gICAgICAgICAgZGF0YU5hc2NpbWVudG86IGRhdGFOYXNjaW1lbnRvLFxyXG4gICAgICAgICAgdGVsZWZvbmU6IFwiIFwiLFxyXG4gICAgICAgICAgZW5kZXJlY286IFwiIFwiLFxyXG4gICAgICAgICAgbm9tZU1hZTogXCIgXCIsXHJcbiAgICAgICAgICBub21lQXBsaWNhZG9yOiBcIiBcIixcclxuICAgICAgICAgIGZhYnJpY2FudGU6IFwiIFwiLFxyXG4gICAgICAgICAgZG9zZTogXCIgXCIsXHJcbiAgICAgICAgfSlcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoMjAxKS5qc29uKHtcclxuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiByZXNwb3N0YS5kYXRhLm1lc3NhZ2UsXHJcbiAgICAgICAgfSlcclxuICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgIGlmIChlLmNvZGUgPT0gJ0VDT05OUkVGVVNFRCcpIHtcclxuICAgICAgICAgIHJldHVybiByZXMuc3RhdHVzKDUwMCkuanNvbih7XHJcbiAgICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICAgICAgICBtZXNzYWdlOlxyXG4gICAgICAgICAgICAgICdFQ09OTlJFRlVTRUQ6IE7Do28gw6kgcG9zc8OtdmVsIHNlIGNvbmVjdGFyIMOgIEFQSSBubyBiYWNrZW5kIScsXHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZS5yZXNwb25zZS5zdGF0dXMgPT0gNDAwKSB7XHJcbiAgICAgICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDApLmpzb24oe1xyXG4gICAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcclxuICAgICAgICAgICAgbWVzc2FnZTogZS5yZXNwb25zZS5kYXRhLm1lc3NhZ2UsXHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gIH1cclxufVxyXG5leHBvcnQgZGVmYXVsdCByZWdpc3RlclxyXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJheGlvc1wiKTs7Il0sInNvdXJjZVJvb3QiOiIifQ==