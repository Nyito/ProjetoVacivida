(function() {
var exports = {};
exports.id = "pages/api/vacina";
exports.ids = ["pages/api/vacina"];
exports.modules = {

/***/ "./pages/api/vacina.js":
/*!*****************************!*\
  !*** ./pages/api/vacina.js ***!
  \*****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

/* JWT secret key */

const KEY = process.env.JWT_KEY;
const urlApi = process.env.URL_API_BACKEND;

const register = async (req, res) => {
  const {
    method
  } = req;

  switch (method) {
    case 'POST':
      const {
        cpf,
        nome,
        dataNascimento,
        telefone,
        endereco,
        nomeMae,
        nomeAplicador,
        fabricante,
        dose
      } = req.body;
      /* Caso o usuário ou senha ou email estiverem em branco... */

      if (!cpf || !nome || !dataNascimento) {
        return res.status(400).json({
          success: false,
          message: 'faltam campos a serem preenchidos'
        });
      }

      try {
        const resposta = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${urlApi}/register`, {
          cpf: cpf,
          nome: nome,
          dataNascimento: dataNascimento,
          telefone: telefone,
          endereco: endereco,
          nomeMae: nomeMae,
          nomeAplicador: nomeAplicador,
          fabricante: fabricante,
          dose: dose
        });
        return res.status(201).json({
          success: true,
          message: resposta.data.message
        });
      } catch (e) {
        if (e.code == 'ECONNREFUSED') {
          return res.status(500).json({
            success: false,
            message: 'ECONNREFUSED: Não é possível se conectar à API no backend!'
          });
        }

        if (e.response.status == 400) {
          return res.status(400).json({
            success: false,
            message: e.response.data.message
          });
        }
      }

  }
};

/* harmony default export */ __webpack_exports__["default"] = (register);

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ (function(module) {

"use strict";
module.exports = require("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./pages/api/vacina.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sZWFybi1zdGFydGVyLy4vcGFnZXMvYXBpL3ZhY2luYS5qcyIsIndlYnBhY2s6Ly9sZWFybi1zdGFydGVyL2V4dGVybmFsIFwiYXhpb3NcIiJdLCJuYW1lcyI6WyJLRVkiLCJwcm9jZXNzIiwiZW52IiwiSldUX0tFWSIsInVybEFwaSIsIlVSTF9BUElfQkFDS0VORCIsInJlZ2lzdGVyIiwicmVxIiwicmVzIiwibWV0aG9kIiwiY3BmIiwibm9tZSIsImRhdGFOYXNjaW1lbnRvIiwidGVsZWZvbmUiLCJlbmRlcmVjbyIsIm5vbWVNYWUiLCJub21lQXBsaWNhZG9yIiwiZmFicmljYW50ZSIsImRvc2UiLCJib2R5Iiwic3RhdHVzIiwianNvbiIsInN1Y2Nlc3MiLCJtZXNzYWdlIiwicmVzcG9zdGEiLCJheGlvcyIsImRhdGEiLCJlIiwiY29kZSIsInJlc3BvbnNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTs7QUFDQSxNQUFNQSxHQUFHLEdBQUdDLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyxPQUF4QjtBQUVBLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDQyxHQUFSLENBQVlHLGVBQTNCOztBQUVBLE1BQU1DLFFBQVEsR0FBRyxPQUFPQyxHQUFQLEVBQVlDLEdBQVosS0FBb0I7QUFDbkMsUUFBTTtBQUFFQztBQUFGLE1BQWFGLEdBQW5COztBQUVBLFVBQVFFLE1BQVI7QUFDRSxTQUFLLE1BQUw7QUFDRSxZQUFNO0FBQUVDLFdBQUY7QUFBT0MsWUFBUDtBQUFhQyxzQkFBYjtBQUE2QkMsZ0JBQTdCO0FBQXVDQyxnQkFBdkM7QUFBaURDLGVBQWpEO0FBQTBEQyxxQkFBMUQ7QUFBeUVDLGtCQUF6RTtBQUFxRkM7QUFBckYsVUFBOEZYLEdBQUcsQ0FBQ1ksSUFBeEc7QUFDQTs7QUFDQSxVQUFJLENBQUNULEdBQUQsSUFBUSxDQUFDQyxJQUFULElBQWlCLENBQUNDLGNBQXRCLEVBQXNDO0FBQ3BDLGVBQU9KLEdBQUcsQ0FBQ1ksTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQzFCQyxpQkFBTyxFQUFFLEtBRGlCO0FBRTFCQyxpQkFBTyxFQUFFO0FBRmlCLFNBQXJCLENBQVA7QUFJRDs7QUFDRCxVQUFJO0FBQ0YsY0FBTUMsUUFBUSxHQUFHLE1BQU1DLGlEQUFBLENBQVksR0FBRXJCLE1BQU8sV0FBckIsRUFBaUM7QUFDdERNLGFBQUcsRUFBRUEsR0FEaUQ7QUFFdERDLGNBQUksRUFBRUEsSUFGZ0Q7QUFHdERDLHdCQUFjLEVBQUVBLGNBSHNDO0FBSXREQyxrQkFBUSxFQUFFQSxRQUo0QztBQUt0REMsa0JBQVEsRUFBRUEsUUFMNEM7QUFNdERDLGlCQUFPLEVBQUVBLE9BTjZDO0FBT3REQyx1QkFBYSxFQUFFQSxhQVB1QztBQVF0REMsb0JBQVUsRUFBRUEsVUFSMEM7QUFTdERDLGNBQUksRUFBRUE7QUFUZ0QsU0FBakMsQ0FBdkI7QUFZQSxlQUFPVixHQUFHLENBQUNZLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUMxQkMsaUJBQU8sRUFBRSxJQURpQjtBQUUxQkMsaUJBQU8sRUFBRUMsUUFBUSxDQUFDRSxJQUFULENBQWNIO0FBRkcsU0FBckIsQ0FBUDtBQUlELE9BakJELENBaUJFLE9BQU9JLENBQVAsRUFBVTtBQUNWLFlBQUlBLENBQUMsQ0FBQ0MsSUFBRixJQUFVLGNBQWQsRUFBOEI7QUFDNUIsaUJBQU9wQixHQUFHLENBQUNZLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUMxQkMsbUJBQU8sRUFBRSxLQURpQjtBQUUxQkMsbUJBQU8sRUFDTDtBQUh3QixXQUFyQixDQUFQO0FBS0Q7O0FBQ0QsWUFBSUksQ0FBQyxDQUFDRSxRQUFGLENBQVdULE1BQVgsSUFBcUIsR0FBekIsRUFBOEI7QUFDNUIsaUJBQU9aLEdBQUcsQ0FBQ1ksTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQzFCQyxtQkFBTyxFQUFFLEtBRGlCO0FBRTFCQyxtQkFBTyxFQUFFSSxDQUFDLENBQUNFLFFBQUYsQ0FBV0gsSUFBWCxDQUFnQkg7QUFGQyxXQUFyQixDQUFQO0FBSUQ7QUFDRjs7QUF6Q0w7QUEyQ0QsQ0E5Q0Q7O0FBK0NBLCtEQUFlakIsUUFBZixFOzs7Ozs7Ozs7OztBQ3JEQSxtQyIsImZpbGUiOiJwYWdlcy9hcGkvdmFjaW5hLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gJ2F4aW9zJ1xyXG4vKiBKV1Qgc2VjcmV0IGtleSAqL1xyXG5jb25zdCBLRVkgPSBwcm9jZXNzLmVudi5KV1RfS0VZXHJcblxyXG5jb25zdCB1cmxBcGkgPSBwcm9jZXNzLmVudi5VUkxfQVBJX0JBQ0tFTkRcclxuXHJcbmNvbnN0IHJlZ2lzdGVyID0gYXN5bmMgKHJlcSwgcmVzKSA9PiB7XHJcbiAgY29uc3QgeyBtZXRob2QgfSA9IHJlcVxyXG5cclxuICBzd2l0Y2ggKG1ldGhvZCkge1xyXG4gICAgY2FzZSAnUE9TVCc6XHJcbiAgICAgIGNvbnN0IHsgY3BmLCBub21lLCBkYXRhTmFzY2ltZW50bywgdGVsZWZvbmUsIGVuZGVyZWNvLCBub21lTWFlLCBub21lQXBsaWNhZG9yLCBmYWJyaWNhbnRlLCBkb3NlIH0gPSByZXEuYm9keVxyXG4gICAgICAvKiBDYXNvIG8gdXN1w6FyaW8gb3Ugc2VuaGEgb3UgZW1haWwgZXN0aXZlcmVtIGVtIGJyYW5jby4uLiAqL1xyXG4gICAgICBpZiAoIWNwZiB8fCAhbm9tZSB8fCAhZGF0YU5hc2NpbWVudG8pIHtcclxuICAgICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDApLmpzb24oe1xyXG4gICAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgICBtZXNzYWdlOiAnZmFsdGFtIGNhbXBvcyBhIHNlcmVtIHByZWVuY2hpZG9zJyxcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9zdGEgPSBhd2FpdCBheGlvcy5wb3N0KGAke3VybEFwaX0vcmVnaXN0ZXJgLCB7XHJcbiAgICAgICAgICBjcGY6IGNwZixcclxuICAgICAgICAgIG5vbWU6IG5vbWUsXHJcbiAgICAgICAgICBkYXRhTmFzY2ltZW50bzogZGF0YU5hc2NpbWVudG8sXHJcbiAgICAgICAgICB0ZWxlZm9uZTogdGVsZWZvbmUsXHJcbiAgICAgICAgICBlbmRlcmVjbzogZW5kZXJlY28sXHJcbiAgICAgICAgICBub21lTWFlOiBub21lTWFlLFxyXG4gICAgICAgICAgbm9tZUFwbGljYWRvcjogbm9tZUFwbGljYWRvcixcclxuICAgICAgICAgIGZhYnJpY2FudGU6IGZhYnJpY2FudGUsXHJcbiAgICAgICAgICBkb3NlOiBkb3NlLFxyXG4gICAgICAgIH0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXMuc3RhdHVzKDIwMSkuanNvbih7XHJcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogcmVzcG9zdGEuZGF0YS5tZXNzYWdlLFxyXG4gICAgICAgIH0pXHJcbiAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICBpZiAoZS5jb2RlID09ICdFQ09OTlJFRlVTRUQnKSB7XHJcbiAgICAgICAgICByZXR1cm4gcmVzLnN0YXR1cyg1MDApLmpzb24oe1xyXG4gICAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcclxuICAgICAgICAgICAgbWVzc2FnZTpcclxuICAgICAgICAgICAgICAnRUNPTk5SRUZVU0VEOiBOw6NvIMOpIHBvc3PDrXZlbCBzZSBjb25lY3RhciDDoCBBUEkgbm8gYmFja2VuZCEnLFxyXG4gICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGUucmVzcG9uc2Uuc3RhdHVzID09IDQwMCkge1xyXG4gICAgICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoNDAwKS5qc29uKHtcclxuICAgICAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IGUucmVzcG9uc2UuZGF0YS5tZXNzYWdlLFxyXG4gICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICB9XHJcbn1cclxuZXhwb3J0IGRlZmF1bHQgcmVnaXN0ZXJcclxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiYXhpb3NcIik7OyJdLCJzb3VyY2VSb290IjoiIn0=